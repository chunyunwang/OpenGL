//
//  _1_OpenGL_____Tests.m
//  01 OpenGL 环境搭建Tests
//
//  Created by CC老师 on 2017/8/28.
//  Copyright © 2017年 Miss CC. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _1_OpenGL_____Tests : XCTestCase

@end

@implementation _1_OpenGL_____Tests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
